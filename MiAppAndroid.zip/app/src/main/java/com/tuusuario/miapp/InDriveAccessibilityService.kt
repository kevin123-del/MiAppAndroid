package com.tuusuario.miapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.LayoutInflater
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.CompoundButton
import android.widget.Switch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class InDriveAccessibilityService : AccessibilityService() {

    companion object {
        const val PAQUETE_DRIVE = "sinet.startup.inDriver"
        @Volatile
        var instancia: InDriveAccessibilityService? = null
            private set
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var repo: SettingsRepository
    private var botActivo = false
    private var ventana: android.view.View? = null
    private var ultimaFirma: String? = null
    private var ultimoMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instancia = this
        repo = SettingsRepository(applicationContext)
        RegistrarLog.agregar("Servicio conectado")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() != PAQUETE_DRIVE) return
        if (!botActivo) return

        val root = rootInActiveWindow ?: return
        val textos = recolectarTextos(root)
        if (textos.isEmpty()) return

        val firma = textos.joinToString("|").hashCode().toString()
        val ahora = System.currentTimeMillis()
        if (firma == ultimaFirma && ahora - ultimoMs < 12000) return
        ultimaFirma = firma
        ultimoMs = ahora

        RegistrarLog.agregar("DEBUG: " + textos.take(12).joinToString(" | "))

        val datos = extraerDatos(textos)
        if (datos == null) {
            RegistrarLog.agregar("Ignorada: no se pudieron leer todos los datos")
            return
        }

        scope.launch {
            val ajustes = repo.leerAjustes()
            val decision = decidir(datos, ajustes)
            RegistrarLog.agregar(
                "Oferta: rec=${datos.recogidaKm}km viaje=${datos.viajeKm}km precio=${datos.precioOfertado} -> $decision"
            )

            delay((1000..3000).random().toLong())

            when (decision.accion) {
                Accion.ACEPTAR -> ejecutarAceptar()
                Accion.OFERTAR -> ejecutarOfertar(decision.monto)
                Accion.IGNORAR -> { }
            }
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instancia = null
        scope.cancel()
        ocultarVentanaFlotante()
        super.onDestroy()
    }

    fun alternarVentanaFlotante() {
        if (ventana != null) ocultarVentanaFlotante() else mostrarVentanaFlotante()
    }

    private fun mostrarVentanaFlotante() {
        if (ventana != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val v = inflater.inflate(R.layout.floating_toggle, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        params.x = 0
        params.y = 200

        val sw = v.findViewById<Switch>(R.id.switchBot)
        sw.isChecked = botActivo
        sw.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            botActivo = checked
            RegistrarLog.agregar(if (checked) "Bot ACTIVADO" else "Bot DESACTIVADO")
        }

        wm.addView(v, params)
        ventana = v
    }

    private fun ocultarVentanaFlotante() {
        ventana?.let {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                wm.removeView(it)
            } catch (_: Throwable) { }
        }
        ventana = null
    }

    private fun recolectarTextos(root: AccessibilityNodeInfo): List<String> {
        val out = mutableListOf<String>()
        fun rec(n: AccessibilityNodeInfo) {
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            for (i in 0 until n.childCount) n.getChild(i)?.let { rec(it) }
        }
        rec(root)
        return out
    }

    private fun extraerDatos(textos: List<String>): DatosOferta? {
        val precioRegex = Regex("""^\s*(?:COP\s*|\$\s*)?([\d.]{3,7})\s*(?:COP)?\s*$""")
        val precio = textos.mapNotNull {
            precioRegex.find(it)?.groupValues?.get(1)?.replace(".", "")?.toIntOrNull()
        }.firstOrNull { it in 500..500_000 } ?: return null

        val recogida = extraerDistancia(textos, listOf("recoger", "recogida", "origen", "pickup"))
        val viaje = extraerDistancia(textos, listOf("viaje", "destino", "trip", "llegada"))

        if (recogida == null || viaje == null) {
            val kmRegex = Regex("""([\d.,]+)\s*km""", RegexOption.IGNORE_CASE)
            val todas = textos.mapNotNull {
                kmRegex.find(it)?.groupValues?.get(1)?.replace(",", ".")?.toDoubleOrNull()
            }
            if (todas.size >= 2) {
                return DatosOferta(todas[0], todas[1], precio)
            }
            return null
        }
        return DatosOferta(recogida, viaje, precio)
    }

    private fun extraerDistancia(textos: List<String>, claves: List<String>): Double? {
        for (t in textos) {
            for (k in claves) {
                if (t.contains(k, ignoreCase = true)) {
                    val m = Regex("""([\d.,]+)\s*km""", RegexOption.IGNORE_CASE).find(t) ?: continue
                    return m.groupValues[1].replace(",", ".").toDoubleOrNull()
                }
            }
        }
        return null
    }

    private fun decidir(d: DatosOferta, a: Ajustes): Decision {
        if (d.recogidaKm > a.maxRecogidaKm) {
            return Decision(Accion.IGNORAR, 0, "recogida ${d.recogidaKm} > ${a.maxRecogidaKm}")
        }
        if (d.viajeKm <= a.maxViajeCortoKm && d.precioOfertado >= a.minAceptable) {
            return Decision(
                Accion.ACEPTAR,
                d.precioOfertado,
                "viaje corto ${d.viajeKm} y precio ${d.precioOfertado}>=${a.minAceptable}"
            )
        }
        val calculado = d.viajeKm * a.valorPorKm
        val base = maxOf(calculado, a.minOferta.toDouble())
        val monto = (base / 100.0).roundToInt() * 100
        return Decision(Accion.OFERTAR, monto, "calc ${d.viajeKm}*${a.valorPorKm}=${calculado} -> $monto")
    }

    private fun ejecutarAceptar() {
        val root = rootInActiveWindow ?: return
        val btn = buscarBoton(root, listOf("Aceptar", "Tomar", "Aceptar oferta"))
        if (btn == null) {
            RegistrarLog.agregar("No se encontró botón Aceptar")
            return
        }
        tocar(btn)
        RegistrarLog.agregar("Toque en Aceptar")
    }

    private fun ejecutarOfertar(monto: Int) {
        val root = rootInActiveWindow ?: return
        val btnOfertar = buscarBoton(root, listOf("Ofertar", "Ofrecer", "Enviar oferta", "Contraoferta"))
        if (btnOfertar == null) {
            RegistrarLog.agregar("No se encontró botón Ofertar")
            return
        }
        tocar(btnOfertar)
        RegistrarLog.agregar("Toque en Ofertar (preparando $monto)")

        scope.launch {
            delay(900)
            val root2 = rootInActiveWindow ?: return@launch
            val campo = buscarEditText(root2)
            if (campo == null) {
                RegistrarLog.agregar("No se encontró campo de texto para el monto")
                return@launch
            }
            val args = Bundle()
            args.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                monto.toString()
            )
            campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            RegistrarLog.agregar("Monto escrito: $monto")

            delay(600)
            val root3 = rootInActiveWindow ?: return@launch
            val enviar = buscarBoton(root3, listOf("Enviar", "Ofertar", "Confirmar", "OK"))
            if (enviar != null) {
                tocar(enviar)
                RegistrarLog.agregar("Oferta enviada: $monto")
            } else {
                RegistrarLog.agregar("No se encontró botón Enviar/Confirmar")
            }
        }
    }

    private fun buscarBoton(root: AccessibilityNodeInfo, claves: List<String>): AccessibilityNodeInfo? {
        val t = root.text?.toString() ?: ""
        val d = root.contentDescription?.toString() ?: ""
        val clazz = root.className?.toString() ?: ""
        if (clazz.contains("Button") || root.isClickable) {
            for (k in claves) {
                if (t.contains(k, true) || d.contains(k, true)) return root
            }
        }
        for (i in 0 until root.childCount) {
            val hijo = root.getChild(i) ?: continue
            buscarBoton(hijo, claves)?.let { return it }
        }
        return null
    }

    private fun buscarEditText(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.isEditable) return root
        val cn = root.className?.toString() ?: ""
        if (cn.contains("EditText")) return root
        for (i in 0 until root.childCount) {
            val hijo = root.getChild(i) ?: continue
            buscarEditText(hijo)?.let { return it }
        }
        return null
    }

    private fun tocar(nodo: AccessibilityNodeInfo) {
        val r = Rect()
        nodo.getBoundsInScreen(r)
        val x = r.centerX().toFloat() + (-10..10).random()
        val y = r.centerY().toFloat() + (-10..10).random()
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x + 2f, y + 2f)
        }
        val dur = (80..150).random().toLong()
        val stroke = GestureDescription.StrokeDescription(path, 0, dur)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}