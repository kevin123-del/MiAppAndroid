package com.tuusuario.miapp

import android.content.Context
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.dataStore by preferencesDataStore(name = "ajustes_bot")

class SettingsRepository(private val context: Context) {

    companion object {
        val MAX_RECOGIDA = doublePreferencesKey("max_recogida_km")
        val VALOR_POR_KM = intPreferencesKey("valor_por_km")
        val MIN_OFERTA = intPreferencesKey("min_oferta")
        val MIN_ACEPTABLE = intPreferencesKey("min_aceptable")
        val MAX_VIAJE_CORTO = doublePreferencesKey("max_viaje_corto_km")
    }

    suspend fun leerAjustes(): Ajustes {
        val prefs = context.dataStore.data.first()
        return Ajustes(
            maxRecogidaKm = prefs[MAX_RECOGIDA] ?: 5.0,
            valorPorKm = prefs[VALOR_POR_KM] ?: 1200,
            minOferta = prefs[MIN_OFERTA] ?: 4800,
            minAceptable = prefs[MIN_ACEPTABLE] ?: 4000,
            maxViajeCortoKm = prefs[MAX_VIAJE_CORTO] ?: 2.0
        )
    }

    suspend fun guardarAjustes(a: Ajustes) {
        context.dataStore.edit { p ->
            p[MAX_RECOGIDA] = a.maxRecogidaKm
            p[VALOR_POR_KM] = a.valorPorKm
            p[MIN_OFERTA] = a.minOferta
            p[MIN_ACEPTABLE] = a.minAceptable
            p[MAX_VIAJE_CORTO] = a.maxViajeCortoKm
        }
    }
}