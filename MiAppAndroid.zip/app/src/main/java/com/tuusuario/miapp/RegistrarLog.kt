package com.tuusuario.miapp

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object RegistrarLog {
    private const val MAX_ENTRADAS = 60
    private val entradas = mutableListOf<String>()

    fun agregar(mensaje: String) {
        val hora = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        synchronized(entradas) {
            entradas.add(0, "[$hora] $mensaje")
            while (entradas.size > MAX_ENTRADAS) entradas.removeAt(entradas.lastIndex)
        }
    }

    fun obtenerTexto(): String = synchronized(entradas) {
        if (entradas.isEmpty()) "(sin registros todavía)" else entradas.joinToString("\n")
    }
}