package com.tuusuario.miapp

data class DatosOferta(
    val recogidaKm: Double,
    val viajeKm: Double,
    val precioOfertado: Int
)

data class Ajustes(
    val maxRecogidaKm: Double,
    val valorPorKm: Int,
    val minOferta: Int,
    val minAceptable: Int,
    val maxViajeCortoKm: Double
)

data class Decision(
    val accion: Accion,
    val monto: Int,
    val motivo: String
)

enum class Accion { ACEPTAR, OFERTAR, IGNORAR }