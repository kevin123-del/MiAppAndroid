package com.tuusuario.miapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var repo: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = SettingsRepository(this)

        val etMaxRecogida = findViewById<EditText>(R.id.etMaxRecogida)
        val etValorKm = findViewById<EditText>(R.id.etValorKm)
        val etMinOferta = findViewById<EditText>(R.id.etMinOferta)
        val etMinAceptable = findViewById<EditText>(R.id.etMinAceptable)
        val etMaxViajeCorto = findViewById<EditText>(R.id.etMaxViajeCorto)

        val btnGuardar = findViewById<Button>(R.id.btnGuardar)
        val btnPermiso = findViewById<Button>(R.id.btnPermisoOverlay)
        val btnAccesibilidad = findViewById<Button>(R.id.btnAbrirAccesibilidad)
        val btnToggleServicio = findViewById<Button>(R.id.btnToggleServicio)
        val tvLog = findViewById<TextView>(R.id.tvLog)

        lifecycleScope.launch {
            val a = repo.leerAjustes()
            etMaxRecogida.setText(a.maxRecogidaKm.toString())
            etValorKm.setText(a.valorPorKm.toString())
            etMinOferta.setText(a.minOferta.toString())
            etMinAceptable.setText(a.minAceptable.toString())
            etMaxViajeCorto.setText(a.maxViajeCortoKm.toString())
        }

        btnGuardar.setOnClickListener {
            val a = Ajustes(
                maxRecogidaKm = etMaxRecogida.text.toString().replace(",", ".").toDoubleOrNull() ?: 5.0,
                valorPorKm = etValorKm.text.toString().toIntOrNull() ?: 1200,
                minOferta = etMinOferta.text.toString().toIntOrNull() ?: 4800,
                minAceptable = etMinAceptable.text.toString().toIntOrNull() ?: 4000,
                maxViajeCortoKm = etMaxViajeCorto.text.toString().replace(",", ".").toDoubleOrNull() ?: 2.0
            )
            lifecycleScope.launch {
                repo.guardarAjustes(a)
                Toast.makeText(this@MainActivity, "Guardado", Toast.LENGTH_SHORT).show()
            }
        }

        btnPermiso.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Ya tienes el permiso", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        btnAccesibilidad.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnToggleServicio.setOnClickListener {
            InDriveAccessibilityService.instancia?.let { svc ->
                svc.alternarVentanaFlotante()
            } ?: Toast.makeText(
                this,
                "Primero activa el servicio en Accesibilidad",
                Toast.LENGTH_LONG
            ).show()
        }

        tvLog.text = RegistrarLog.obtenerTexto()
    }

    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.tvLog)?.text = RegistrarLog.obtenerTexto()
    }
}